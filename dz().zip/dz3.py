a = '* * * * *'
b = 1
while b <= 5:
    print(a)
    b += 1

