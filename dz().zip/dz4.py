a = '*'
b = 1
while b <= 4:
    print(a)
    a = a + ' *'
    b += 1