value = 100
while value > 0:
 n = int(input("Enter value: "))
 if ((value - n) < 0):
  print("value can't be < 0")
  continue
 value -= n
 print("You have", value)
