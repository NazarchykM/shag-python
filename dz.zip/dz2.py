a = 11
while a <= 29:
    if a % 2:
        print(a)
    a += 1

