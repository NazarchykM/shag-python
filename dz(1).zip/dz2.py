import random
s1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
s2 = "0123456789"
s3 = "~!@#$%^&*()_+{}[\]:/"
s = s1.upper() + s1.lower() + s2 + s3
password = ""
for i in range(15):
 r = random.choice(s)
 password = password + r
print(f"New password : {password}")
if (len(password) < 5):
    print("False. Password length must have 5 or more symbols")
else:
    print("True")
if (password.find("A") < 0 and password.find("a") < 0 and password.find("Z") < 0 and password.find("z") < 0):
    print("Error. Password must have -A- or -a- or -Z- or -z-")
else:
    print("True")
if (password.find("0") < 0 and password.find("1") < 0 and password.find("2") < 0 and password.find("3") < 0 and password.find("4") < 0 and password.find("5") < 0 and password.find("6") < 0 and password.find("7") < 0 and password.find("8") < 0 and password.find("9") < 0):
    print("Error. Password must have numbers")
else:
    print("True")
if (password.find("@") < 0 and password.find("#") < 0 and password.find("%") < 0 and password.find("&") < 0):
    print("Error. Password must have @ or # or % or &")
else:
    print("True")
